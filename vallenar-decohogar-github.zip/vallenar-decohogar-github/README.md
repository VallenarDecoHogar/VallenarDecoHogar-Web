# Vallenar DecoHogar 🪷

Tienda online chilena de aromaterapia, esoterismo, inciensos y decoración sagrada importada desde India.

## 🛍️ Características

- **202 productos** en catálogo (170 de decoración, 10 aromaterapia, 10 esoterismo, 13 incienso)
- **Sistema de usuarios** con registro, login y carrito persistente
- **Buscador inteligente** con autocompletado e historial
- **Modo día/noche** con paleta adaptada
- **Panel de administración** para ajustar markups dinámicamente
- **Carrito** con Webpay + Mercado Pago
- **Botón flotante de WhatsApp**
- **Variantes de producto** (tamaños, packs)
- **Responsive** (funciona en celular y computador)

## 🛠️ Tecnología

- **Next.js 16** + TypeScript
- **Tailwind CSS 4** + shadcn/ui
- **Prisma ORM** + PostgreSQL
- **JWT** para autenticación
- **next-themes** para modo día/noche

## 🚀 Deploy

Ver [GUIA-DEPLOY.md](./GUIA-DEPLOY.md) para instrucciones detalladas de cómo desplegar en Vercel gratis.

## 📁 Estructura

```
src/
├── app/
│   ├── page.tsx              # Inicio
│   ├── catalogo/             # Catálogo + páginas de categoría
│   ├── cuenta/               # Login, registro, perfil
│   ├── contacto/             # Formulario + FAQ
│   └── api/                  # API routes (auth, cart, wishlist)
├── components/site/          # Componentes de la tienda
├── lib/
│   ├── products.ts           # Catálogo de 202 productos
│   ├── store.tsx             # Estado global (cart, wishlist, auth)
│   └── auth.ts               # Autenticación JWT
└── prisma/
    └── schema.prisma         # Modelos de base de datos
```

## 💰 Reglas de precios

- Markup 150% para productos < $100.000
- Markup 75% para productos >= $100.000
- Redondeo hacia arriba a múltiplos limpios

## 🎨 Paleta de colores

- Crema cálido: #fffbf5
- Marrón oscuro: #482113
- Coral terracota: #f17b5d
- Verde salvia: #b4ba8f
